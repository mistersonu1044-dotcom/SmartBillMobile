'use strict';
// Minimal single-shop JSON sync server for SmartBill. Use HTTPS via a reverse proxy in production.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PORT = Number(process.env.PORT || 8080);
const API_KEY = process.env.SMARTBILL_API_KEY || '';
const DATA_DIR = process.env.SMARTBILL_DATA_DIR || path.join(__dirname, 'data');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
fs.mkdirSync(BACKUP_DIR, {recursive:true});
if (!API_KEY) console.warn('WARNING: Set SMARTBILL_API_KEY before using this server. Requests will be rejected.');

function send(res, status, data) {
  res.writeHead(status, {
    'Content-Type':'application/json; charset=utf-8',
    'Access-Control-Allow-Origin':'*',
    'Access-Control-Allow-Methods':'GET, PUT, OPTIONS',
    'Access-Control-Allow-Headers':'Content-Type, x-smartbill-key'
  });
  res.end(JSON.stringify(data));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = ''; req.on('data', chunk => { body += chunk; if (body.length > 5*1024*1024) { reject(new Error('Body too large')); req.destroy(); } });
    req.on('end', () => { try { resolve(JSON.parse(body || '{}')); } catch(e) { reject(e); } });
    req.on('error', reject);
  });
}
function safeShopId(s) { return String(s || 'main-shop').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0,80) || 'main-shop'; }
function statePath(shop) { return path.join(DATA_DIR, safeShopId(shop) + '.json'); }
function loadState(shop) {
  const file = statePath(shop);
  if (!fs.existsSync(file)) return {revision:0, state:{}};
  try { return JSON.parse(fs.readFileSync(file,'utf8')); } catch { return {revision:0,state:{}}; }
}
function auth(req) { const got = Buffer.from(String(req.headers['x-smartbill-key'] || '')); const expected = Buffer.from(API_KEY); return Boolean(API_KEY) && got.length === expected.length && crypto.timingSafeEqual(got, expected); }
const server = http.createServer(async (req,res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/health') return send(res,200,{ok:true,service:'SmartBill sync server'});
  if (url.pathname !== '/api/state') return send(res,404,{error:'Not found'});
  if (!auth(req)) return send(res,401,{error:'Unauthorized'});
  const shopId = safeShopId(url.searchParams.get('shopId') || 'main-shop');
  if (req.method === 'GET') return send(res,200,loadState(shopId));
  if (req.method !== 'PUT') return send(res,405,{error:'Method not allowed'});
  try {
    const body = await readBody(req);
    const current = loadState(body.shopId || shopId);
    const targetShop = safeShopId(body.shopId || shopId);
    if (Number(body.expectedRevision || 0) !== Number(current.revision || 0)) return send(res,409,{error:'Revision conflict',revision:current.revision,state:current.state});
    if (!body.state || typeof body.state !== 'object' || Array.isArray(body.state)) return send(res,400,{error:'state must be an object'});
    const next = {revision:Number(current.revision || 0)+1, updatedAt:new Date().toISOString(), state:body.state};
    const file = statePath(targetShop);
    if (fs.existsSync(file)) {
      const stamp = new Date().toISOString().replace(/[:.]/g,'-');
      const backup = path.join(BACKUP_DIR, `${targetShop}-${stamp}.json`);
      fs.copyFileSync(file,backup);
    }
    const tmp = file + '.tmp'; fs.writeFileSync(tmp,JSON.stringify(next,null,2),'utf8'); fs.renameSync(tmp,file);
    return send(res,200,{revision:next.revision,updatedAt:next.updatedAt});
  } catch(e) { return send(res,400,{error:'Invalid request',message:e.message}); }
});
server.listen(PORT,'0.0.0.0',()=>console.log(`SmartBill sync server listening on ${PORT}`));
