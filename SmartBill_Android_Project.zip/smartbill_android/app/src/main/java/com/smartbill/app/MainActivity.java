package com.smartbill.app;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.text.InputType;
import android.content.Intent;
import android.net.Uri;

import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private static final String PREFS = "smartbill_server_settings";

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF075E68);
        getWindow().setNavigationBarColor(0xFFFFFFFF);
        getWindow().getDecorView().setSystemUiVisibility(0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFFFFFFF);
        TextView bar = new TextView(this);
        bar.setText("  SuperMarket Billing Pro                         ⋮");
        bar.setTextColor(0xFFFFFFFF);
        bar.setTextSize(17);
        bar.setTypeface(null, 1);
        bar.setPadding(16, 16, 12, 16);
        bar.setBackgroundColor(0xFF075E68);
        bar.setOnClickListener(v -> showServerSettings());
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.addJavascriptInterface(new AndroidConfigBridge(), "AndroidConfig");
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                return true;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Server Settings").setOnMenuItemClickListener(item -> { showServerSettings(); return true; });
        menu.add("Reload App").setOnMenuItemClickListener(item -> { webView.reload(); return true; });
        return true;
    }

    private void showServerSettings() {
        android.content.SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        LinearLayout layout = new LinearLayout(this);
        layout.setPadding(22, 8, 22, 0);
        layout.setOrientation(LinearLayout.VERTICAL);
        EditText url = field("Server URL (e.g. https://your-domain.com/api)", p.getString("apiBase", ""));
        EditText shop = field("Shop ID", p.getString("shopId", "main-shop"));
        EditText key = field("Private API Key", p.getString("apiKey", ""));
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        layout.addView(url); layout.addView(shop); layout.addView(key);
        TextView note = new TextView(this);
        note.setText("Leave Server URL and API Key blank to use offline mode only. A real HTTPS server must be set up first.");
        note.setPadding(0, 12, 0, 4);
        layout.addView(note);
        new AlertDialog.Builder(this).setTitle("Cloud Sync Settings").setView(layout)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save & Reload", (d, w) -> {
                String base = url.getText().toString().trim().replaceAll("/+$", "");
                p.edit().putString("apiBase", base).putString("shopId", shop.getText().toString().trim().isEmpty() ? "main-shop" : shop.getText().toString().trim()).putString("apiKey", key.getText().toString().trim()).apply();
                webView.reload();
            }).show();
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setHint(hint); e.setText(value); e.setPadding(8, 8, 8, 8);
        return e;
    }

    private class AndroidConfigBridge {
        @JavascriptInterface public String getConfig() {
            android.content.SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONObject o = new JSONObject();
            try {
                o.put("apiBase", p.getString("apiBase", ""));
                o.put("shopId", p.getString("shopId", "main-shop"));
                o.put("apiKey", p.getString("apiKey", ""));
            } catch (Exception ignored) {}
            return o.toString();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
