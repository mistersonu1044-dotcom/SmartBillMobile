# SuperMarket Billing Pro — Android project + sync server starter

This package wraps the supplied HTML app in an Android WebView while preserving its design and using WebView local storage for offline use. It also includes a small self-hostable sync API starter.

## Important status
- This is **Android Studio source code**, not a compiled APK. This environment does not have the Android SDK/Gradle installed, so it could not produce or test an APK here.
- Offline local billing is supported by the bundled HTML/local storage, but this project has not been tested on a physical Android device.
- Cloud sync will not work until you deploy the server on a public HTTPS domain and configure its API URL and key in the app.
- Automatic backups are written by the server before each successful update. Configure separate server/hosting backups too; backups are not a guarantee against every kind of data loss.

## Build the APK
1. Install Android Studio on a computer.
2. Open this `smartbill_android` folder as an existing project.
3. Allow Android Studio to install the Android SDK / Gradle components it requests (compile SDK 35).
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the output APK location. Test it with sample data before using real bills.

## Cloud server setup
The `server/` folder is a small Node.js starter API. It requires Node.js 18+ and should be deployed on a server behind HTTPS (for example, with a reverse proxy such as Caddy or Nginx). Do not expose the raw HTTP port directly to the public internet.

Example environment variables:
- `SMARTBILL_API_KEY`: a long, random secret key
- `PORT`: port for the Node process (default 8080)
- `SMARTBILL_DATA_DIR`: optional path for persistent data

Start locally for development:
```sh
cd server
SMARTBILL_API_KEY='replace-with-a-long-random-secret' npm start
```

Health check: `GET /health`
Sync API: `GET /api/state?shopId=main-shop` and `PUT /api/state` with `x-smartbill-key` header. The app uses optimistic revisions to avoid silently overwriting a newer server state.

## Configure the Android app
1. Open the installed app.
2. Tap the teal title bar at the top to open **Cloud Sync Settings**.
3. Enter the server URL ending in `/api`, for example `https://billing.example.com/api`.
4. Enter the same API key configured on the server and keep Shop ID as `main-shop` unless you deliberately use another one.
5. Save & Reload.

Leave URL/key blank to use local/offline mode only. Never share the API key. This starter does not include a multi-user account system; it is configured for one shop and one owner's phone as requested.

## Before live use
- Configure HTTPS and a strong private API key.
- Test creating/editing bills offline, then reconnecting and syncing.
- Keep a separate backup of the server data directory.
- Do not treat this starter server as production-hardened without security review and restore testing.
